﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Меропрятия
{
    /// <summary>
    /// Логика взаимодействия для WindowOrganizer.xaml
    /// </summary>
    public partial class WindowOrganizer : Window
    {
        bd.Organizer organizers;
        int idOrganizer;
        public WindowOrganizer(bd.Organizer organizer)
        {
            InitializeComponent();
            organizers = organizer;
            idOrganizer = organizer.idOrganizers;
            GreetUser();
            ForNameForm();
        }
        private void GreetUser()
        {
            string timeOfDay = GetTimeOfDay();

            string greeting = $" {timeOfDay}!";
            ForGreeting.Text = greeting;
        }

        public void ForNameForm()//Для указания мени перосоны
        {
            if (organizers.id_Gender == 1)//женщина
            {
                ForNamePerson.Text = "Ms " + organizers.FIO.ToString();
            }
            else
            {
                if (organizers.id_Gender == 2)//мужчина
                {
                    ForNamePerson.Text = "Mrs " + organizers.FIO.ToString();
                }
            }
        }
        private string GetTimeOfDay()
        {
            DateTime now = DateTime.Now;
            if (now.Hour >= 9 && now.Hour <= 11)
            {
                return "Доброе утро";
            }
            else if (now.Hour >= 11 && now.Hour <= 18)
            {
                return "Добрый день";
            }
            else
            {
                return "Добрый вечер";
            }
        }

        private void btRegist_Click(object sender, RoutedEventArgs e)
        {
            Registration windowRegistration =
                new Registration();
            windowRegistration.Show();
            this.Close();
        }
    }
}
