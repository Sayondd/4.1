﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Меропрятия
{
    /// <summary>
    /// Логика взаимодействия для Captha.xaml
    /// </summary>
    public partial class Captha : Window
    {
        int error = 0;
        MainWindow mainWindow = new MainWindow();
        int not = 15;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        public Captha()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            String allowchar = " ";

            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";

            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";

            allowchar += "1,2,3,4,5,6,7,8,9,0";

            char[] a = { ',' };

            String[] ar = allowchar.Split(a);

            String pwd = "";

            string temp = " ";

            Random r = new Random();
            for (int i = 0; i < 6; i++)
            {
                temp = ar[(r.Next(0, ar.Length))];
                pwd += temp;
            }
            tb.Text = pwd;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Window_Loaded(sender, e);
            capcha.Clear();
        }

        private void Button2_Click_1(object sender, RoutedEventArgs e)
        {
            if (capcha.Text != tb.Text)
            {
                error++;
                if (error == 3)
                {
                    mainWindow.IsEnabled = false;
                    this.IsEnabled = false;
                    capcha.Clear();
                    MessageBox.Show("Слишком много попыток, подождите", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    timer.Tick += new EventHandler(timerTick);
                    timer.Interval = new TimeSpan(0, 0, 1);
                    timer.Start();
                }
                else
                {
                    Window_Loaded(sender, e);
                    capcha.Clear();
                    MessageBox.Show("Не верно");
                }


            }
            else
            {
                MessageBox.Show("Верно");
                Close();
            }
        }
        private void timerTick(object sender, EventArgs e)
        {
            if (not == 0)
            {
                mainWindow.IsEnabled = true;
                this.IsEnabled = true;
                MessageBox.Show("Можете вводить captcha");
                timer.Stop();
                error = 0;
                not = 15;
            }
            else
            {
                not--;
            }

        }
    }
}
