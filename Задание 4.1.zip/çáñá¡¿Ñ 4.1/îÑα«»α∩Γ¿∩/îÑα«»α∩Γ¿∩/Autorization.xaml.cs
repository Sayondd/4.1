﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Меропрятия
{
    /// <summary>
    /// Логика взаимодействия для Autorization.xaml
    /// </summary>
    public partial class Autorization : Window
    {
        int Attempts;
        DateTime now = DateTime.Now;//текущие дата и время  
        int idUser;
        public Autorization()
        {
            InitializeComponent();
        }

        private void check_Click(object sender, RoutedEventArgs e)
        {
            if (check.IsChecked == true)
            {
                pas.Text = pass.Password;
                pas.Visibility = Visibility.Visible;
                pass.Visibility = Visibility.Collapsed;
            }
            else
            {
                pass.Password = pas.Text;
                pas.Visibility = Visibility.Collapsed;
                pass.Visibility = Visibility.Visible;
            }
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var forJury = App.entities.Juries.FirstOrDefault
                (c => c.Email == login.Text
                & c.Password == pas.Text);
                var forModerator = App.entities.Moderators.FirstOrDefault
                    (c => c.Email == login.Text
                    & c.Password == pas.Text);
                var forOrganizer = App.entities.Organizers.FirstOrDefault
                    (c => c.Email == login.Text
                    & c.Password == pas.Text);
                var forParticipants = App.entities.Participants.FirstOrDefault
                    (c => c.Email == login.Text
                    & c.Password == pas.Text);
                if (forJury != null)
                {
                    if (forJury.id_Role == 1)
                    {
                        JuryModerator windowJuryModerator
                          = new JuryModerator();
                        windowJuryModerator.TextForUsers.Text = "Окно жюри";
                        windowJuryModerator.Show();
                        this.Close();
                    }
                    else
                    {
                        Attempts++;
                        UsersFalse();
                    }
                }
                else
                {
                    if (forModerator != null)
                    {
                        if (forModerator.id_Role == 2)
                        {
                            JuryModerator windowJuryModerator
                              = new JuryModerator();
                            windowJuryModerator.TextForUsers.Text = "Окно модератора";
                            windowJuryModerator.Show();
                            this.Close();
                            this.Close();
                        }
                        else
                        {
                            Attempts++;
                            UsersFalse();
                        }
                    }
                    else
                    {
                        if (forOrganizer != null)
                        {
                            if (forOrganizer.id_Role == 3)
                            {
                                WindowOrganizer windowOrganizer
                                   = new WindowOrganizer(forOrganizer);
                                windowOrganizer.Show();
                                this.Close();
                            }
                        }
                        else
                        {
                            Attempts++;
                            UsersFalse();
                        }
                    }

                }
            }
            catch
            { }
            }
        System.Windows.Threading.DispatcherTimer timer1 = new System.Windows.Threading.DispatcherTimer();
        public void UsersFalse()//Блок неверной капчи
        {
            if (Attempts == 1 || Attempts == 2)
            {
                MessageBoxResult result = MessageBox.Show("Неверно введёт логин или пароль." +
                    "\nПроверьте введённые вами данные!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Attempts == 3)
            {
                Captha captha = new Captha();
                captha.ShowDialog();
            }
            if (Attempts >= 4)//если пользователь продолжает вводить неверно логин и пароль
            {//вход продолжает блокироваться на 10 секунд
                timer1.Tick += new EventHandler(timerTick2);
                timer1.Interval = new TimeSpan(0, 0, 1);
                timer1.Start();
                if (stop != 0)
                {
                    login.IsEnabled = false;
                    pass.IsEnabled = false;
                    pas.IsEnabled = false;
                    //Authoriz.IsEnabled = false;
                    MessageBox.Show(String.Format("Вход заблокирован на {0:0} секунд", stop));
                }
            }
        }
        int stop = 10;
        private void timerTick2(object sender, EventArgs e)//Блокировка входа и заполнения при последующих неверных входах
        {
            if (stop == 0)
            {
                login.IsEnabled = true;
                pass.IsEnabled = true;
                pas.IsEnabled = true;
                MessageBoxResult result = MessageBox.Show("Время вышло!\nПовторите вход заново!",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                timer1.Stop();
                stop = 10;
            }
            else
            {
                stop--;
            }

        }
    }
}
